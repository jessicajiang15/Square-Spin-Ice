using Plots
x = 1:10; y = rand(10); # These are the plotting data
plot(x, y)
display(plot(x, y))
